#ifndef _GP_H_
#define _GP_H_

void gp_Init(void);


#endif
