#include "pid.h"
#include "stm32f4xx.h"
#include "stdio.h"
float inc;
int z;
extern float front;
extern float left ;
extern int mode;
extern PID_Struct pid_data;
extern PID_Struct pid_data1;
void pid_init(PID_Struct* PID,float set_val,float Kp,float Ki,float Kd)
{
	PID->set = set_val;
	PID->Kp = Kp;
	PID->Ki = Ki;
	PID->Kd = Kd;
	PID->output = 0.0;
	PID->error = 0.0;
	PID->err_next =0.0;
}

int pid_compute(PID_Struct* pid,float angle)
{
	float p = 0,i = 0,d = 0;	
	pid->error = pid->set - angle;
	if(mode == 3)
	{
	if(inc < 80000)
	inc += pid->error;
  }
	else 
	inc += pid->error;
	p = pid->Kp * pid->error ;
	i = pid->Ki * inc ;
	d = pid->Kd * (pid->error - pid->err_next);
	pid->output = p + i + d;
	pid->err_next = pid->error;
	if(z%10 == 0 || z%10 == 1)
	printf("p:%.1f  i:%.1f d:%.1f  out:%.1f\r\n",p,i,d,pid->output);
  z++;
	return pid->output;
}

void TIM7_Init(u16 arr,u16 psc)
{
		TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure; 
		NVIC_InitTypeDef NVIC_InitStructure;
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE);
		TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
		TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
		TIM_TimeBaseStructure.TIM_Period = arr;
		TIM_TimeBaseStructure.TIM_Prescaler = psc;
	
		TIM_TimeBaseInit(TIM7,&TIM_TimeBaseStructure);
		TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE);

		NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =2 ;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
		NVIC_Init(&NVIC_InitStructure);
	
		TIM_Cmd(TIM7,ENABLE);
}

void TIM7_IRQHandler()
{
	float fr = 0;
	float le = 0;
	float fro = 0;
	float lef = 0;
	if( TIM_GetITStatus(TIM7,TIM_IT_Update) == SET )
	{
			if(mode == 3 || mode == 4 || mode == 2)
		{
			lef = left;
			fro = front;
			if(front < 0)
			front = -front;
			if(left < 0)
			left = -left;
			fr =	pid_compute(&pid_data,front);
			le =	pid_compute(&pid_data1,left);
			if(z%10 == 0 )
			printf("fr1%.1f\tle1%.1f\r\n",fr,le);
		}
		else 
			{
	fr =	pid_compute(&pid_data,front);
	le =	pid_compute(&pid_data1,left);
		}
		if(fr < 0)
			fr = -fr;
		if(le < 0)
			le = -le;


		
//ͣ		
if(mode == 1)
{
		if(fr >= 999)
			fr = 999;
		if(le >= 999)
			le = 999;
		if(front <= 0)
		{	
		TIM_SetCompare1(TIM13,500 - fr);
		TIM_SetCompare1(TIM11,fr + 400);
		}
else if(front > 0)
		{
		TIM_SetCompare1(TIM11,400 - fr);
		TIM_SetCompare1(TIM13,500 + fr);
		}
		if(left >= 0)
		{
		TIM_SetCompare1(TIM12,500 - le);
		TIM_SetCompare1(TIM2,le + 400);
		}
	else if(left < 0)
		{
		TIM_SetCompare1(TIM2,400 - le);
		TIM_SetCompare1(TIM12,le + 500);
		}		
}
		
	
	
	
//��
if(mode == 2)
{
		if(fr >= 500)
			fr = 500;
	if(fro >= 0)
		{
			TIM_SetCompare1(TIM13,0);
			TIM_SetCompare1(TIM11, fr);
			TIM_SetCompare1(TIM2,0);
			TIM_SetCompare1(TIM12,fr);
		}
else if(fro < 0)
		{
			TIM_SetCompare1(TIM11,0);
			TIM_SetCompare1(TIM13,fr);
			TIM_SetCompare1(TIM12,0);
			TIM_SetCompare1(TIM2,fr);
		}	

}



//Բ
if(mode == 3)
	{		

		if(fr >= 999)
			fr = 999;
				if(le >= 999)
			le = 999;
			if(fro > 0)
		{

		TIM_SetCompare1(TIM13,500 - fr);
		TIM_SetCompare1(TIM11,fr + 500);
		}
		if(fro <= 0)
		{

		TIM_SetCompare1(TIM11,500 - fr);
		TIM_SetCompare1(TIM13,fr + 500);
		}
		if(lef >= 0)
		{

		TIM_SetCompare1(TIM2,500 - le);
		TIM_SetCompare1(TIM12,le + 500);
		}
		if(lef < 0)
		{

		TIM_SetCompare1(TIM12,500 - le);
		TIM_SetCompare1(TIM2,le + 500);
		}
//		if(z%10 == 0 )
//printf("fr%.1f\tle%.1f\r\n",fr,le);
	}
		
//ֱ�߶�
if(mode == 4)
{
	if(fr >= 999)
	fr = 999;
//	TIM_SetCompare1(TIM2,999);
//	TIM_SetCompare1(TIM12,999);
	  if(fro >= 0)
		{	
		TIM_SetCompare1(TIM13,0);
		TIM_SetCompare1(TIM11,fr);
		}
else if(fro < 0)
		{
		TIM_SetCompare1(TIM11,0);
		TIM_SetCompare1(TIM13,fr);
		}
		if(le >= 999)
			le = 999;
		if(lef >= 0)
		{
		TIM_SetCompare1(TIM12,500 - le);
		TIM_SetCompare1(TIM2,le + 500);
		}
	else if(lef < 0)
		{
		TIM_SetCompare1(TIM2,500 - le);
		TIM_SetCompare1(TIM12,le + 500);
		}		
}
		TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
	}
}
