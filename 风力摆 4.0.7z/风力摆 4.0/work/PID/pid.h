#ifndef __PID___H
#define __PID___H
#include "stm32f4xx.h"
typedef struct{
	float set;
	float	Kp;
	float Ki;
	float Kd;
	float err_next;
	float err_last;
	float error;
	float output;
	
}PID_Struct;
int pid_compute(PID_Struct* pid,float angle);
void TIM7_Init(u16 arr,u16 psc);
void pid_init(PID_Struct* PID,float set_val,float Kp,float Ki,float Kd);
#endif

