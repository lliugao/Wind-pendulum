#ifndef PWM_H_
#define PWM_H_
#include "stm32f4xx.h"

void TIM11_PWM_Init(u32 auto_data,u32 fractional);
void TIM13_PWM_Init(u32 auto_data,u32 fractional);
void TIM2_PWM_Init(u32 auto_data,u32 fractional);
void TIM12_PWM_Init(u32 auto_data,u32 fractional);
#endif

