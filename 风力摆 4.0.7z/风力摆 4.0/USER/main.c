#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "pwm.h"
#include "sys.h"
#include "gp.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "pid.h"
//ALIENTEK ̽����STM32F407������ ʵ��0
//STM32F4����ģ��-�⺯���汾
//����֧�֣�www.openedv.com
//�Ա����̣�http://eboard.taobao.com
//�������������ӿƼ����޹�˾  
//���ߣ�����ԭ�� @ALIENTEK
float front;
float left ;
float lin;
int m;
int mode = 3;
extern void TIM11_PWM_Init(u32 auto_data,u32 fractional);
extern void TIM13_PWM_Init(u32 auto_data,u32 fractional);
extern void TIM2_PWM_Init(u32 auto_data,u32 fractional);
extern void TIM12_PWM_Init(u32 auto_data,u32 fractional);
PID_Struct pid_data;
PID_Struct pid_data1;
int main(void)
{
	float pitch,roll,yaw;
	uart_init(115200);
	delay_init(168);
	TIM7_Init(999,839);
	gp_Init();
	MPU_Init();
	//ǰ
	TIM11_PWM_Init(1000-1,168-1);
	//��
	TIM13_PWM_Init(1000-1,84-1);
		//��
	TIM12_PWM_Init(1000-1,84-1);
	//��
	TIM2_PWM_Init(1000-1,84-1);
	//ͣ
	if(mode == 1)
	{
  //ǰ��
  pid_init(&pid_data,0,130,0.0065,25);
  //����	
	pid_init(&pid_data1,0,130,0.0065,25);
	}
	//��
	if(mode == 2)
	{
	pid_init(&pid_data,10,50,0.005,5);

	}
	//��Բ
	if(mode == 3)
	{
	//ǰ��
  pid_init(&pid_data,11,38,0.004,20);
  //����	
	pid_init(&pid_data1,11,24,0.0020,30);
	}
	//ֱ�߶�
	if(mode == 4)
	{
	//ǰ��
  pid_init(&pid_data,19,70,0,30);
	pid_init(&pid_data1,0,135,0.0002,30);
	}
while(mpu_dmp_init())
	{

 		delay_ms(200);
	}

  while(1){
		
		if(mpu_dmp_get_data(&pitch,&roll,&yaw)==0)
		{ 

			front=roll;
			left = pitch;
		//	lin = yaw;
			if(m%5 == 0)
			printf("A%.1f  B%.1f   \r\n",front,left);
			m++;
		}
		//ǰ��
		GPIO_ResetBits(GPIOE,GPIO_Pin_0); 
	  GPIO_SetBits(GPIOE,GPIO_Pin_1); 
		GPIO_ResetBits(GPIOE,GPIO_Pin_2); 
	  GPIO_SetBits(GPIOE,GPIO_Pin_3);
		//����
		GPIO_ResetBits(GPIOB,GPIO_Pin_7); 
	  GPIO_SetBits(GPIOB,GPIO_Pin_6); 
		GPIO_ResetBits(GPIOB,GPIO_Pin_9); 
	  GPIO_SetBits(GPIOB,GPIO_Pin_8);
	}
}

